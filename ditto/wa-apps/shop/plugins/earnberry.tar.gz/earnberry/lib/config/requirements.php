<?php
return array(
    'php.curl' => array(
        'strict' => true,
        'value'  => 1,
    ),
    'php.iconv' => array(
        'strict' => true,
        'value'  => 1,
    ),
);
